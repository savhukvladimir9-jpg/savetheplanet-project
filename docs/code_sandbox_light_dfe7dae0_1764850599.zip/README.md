# 🌍 Save The Planet Token (STP)

![STP Banner](https://www.genspark.ai/api/files/s/VmZ4g06h)

**Each Token Saves a Life on Earth**

> A revolutionary blockchain initiative dedicated to global environmental welfare. Join us in creating a sustainable future through cryptocurrency.

---

## 📋 Table of Contents

- [About the Project](#about-the-project)
- [Features](#features)
- [Technology Stack](#technology-stack)
- [Tokenomics](#tokenomics)
- [Project Structure](#project-structure)
- [Installation & Usage](#installation--usage)
- [Roadmap](#roadmap)
- [Team](#team)
- [Contributing](#contributing)
- [License](#license)

---

## 🌱 About the Project

Save The Planet Token (STP) is a groundbreaking cryptocurrency project that merges blockchain technology with environmental activism. Our mission is to create a decentralized ecosystem where every token holder contributes to global environmental rescue efforts.

### Mission Statement

**"Together We Save The Planet | One Token — One Good Deed | Blockchain for Real Change"**

To create a decentralized ecosystem where cryptocurrency meets environmental activism. Through innovative blockchain solutions, we empower individuals to participate in global environmental rescue efforts while building a sustainable financial future. We unite people worldwide to save our planet — making it cleaner, people happier, and the future safer.

### Core Values

- 🌍 **Environmental Impact**: 50% of funds directly to eco-projects
- 🔒 **Transparency**: Blockchain-based tracking of all donations
- 👥 **Community Driven**: Governed by token holders
- 📈 **Sustainable Growth**: Long-term vision for planet and profit

---

## ✨ Features

### Currently Implemented Features

✅ **Professional Landing Page**
- Modern, responsive design inspired by leading crypto projects (Starknet, Optimism)
- Dark teal background with gold accents matching brand identity
- Fully animated and interactive user experience

✅ **Hero Section**
- Compelling value proposition
- Real-time token statistics counter
- Animated background with particle effects
- Call-to-action buttons for token purchase and whitepaper

✅ **About Section**
- Four key feature cards with hover effects
- Mission statement with clear environmental goals
- Social proof and trust indicators

✅ **Tokenomics Visualization**
- Interactive Chart.js doughnut chart
- Detailed breakdown of token distribution:
  - 50% Eco-Fund (Charity & Planet Rescue)
  - 20% Liquidity Pool
  - 15% Development & Team
  - 10% Investors
  - 5% Airdrops & Community Rewards
- Token information grid (Supply, Symbol, Blockchain, Standard)

✅ **Roadmap Section**
- Timeline visualization with 5 phases (Q1 2024 - Q1 2025)
- Progress indicators for completed/active/upcoming milestones
- Detailed objectives for each quarter

✅ **Team Section**
- Founder profile (Vladimir)
- Additional team members showcase
- Social media integration

✅ **Contact & Newsletter**
- Social media links (Telegram, Twitter, Discord, Medium)
- Newsletter subscription form with validation
- Success/error notifications

✅ **Responsive Navigation**
- Sticky header with scroll effects
- Mobile-friendly hamburger menu
- Smooth scroll to sections
- Active link highlighting

✅ **Animations & Interactions**
- AOS (Animate On Scroll) library integration
- Counter animations for statistics
- Particle effects and parallax scrolling
- Hover effects on cards and buttons
- Floating card animation for token display

---

## 🛠 Technology Stack

### Frontend Technologies

- **HTML5**: Semantic markup structure
- **CSS3**: Modern styling with CSS Grid and Flexbox
  - Custom CSS variables for theming
  - Smooth transitions and animations
  - Fully responsive design (mobile-first approach)
  
- **JavaScript (ES6+)**: 
  - Vanilla JS for core functionality
  - Event delegation and DOM manipulation
  - Intersection Observer API for scroll effects
  
### Libraries & Frameworks

| Library | Version | Purpose |
|---------|---------|---------|
| **Inter Font** | Latest | Professional typography |
| **Font Awesome** | 6.4.0 | Icon library |
| **Chart.js** | Latest | Tokenomics visualization |
| **AOS** | 2.3.1 | Scroll animations |

### Color Palette

```css
/* Primary Colors */
--primary-bg: #0a1f1f      /* Dark teal background */
--secondary-bg: #0d2828    /* Secondary background */
--tertiary-bg: #153838     /* Card backgrounds */

/* Accent Colors */
--accent-gold: #f4d03f     /* Primary accent - gold */
--accent-yellow: #ffe66d   /* Secondary accent */
--accent-green: #2ecc71    /* Success/eco color */
--accent-teal: #1abc9c     /* Highlight color */

/* Text Colors */
--text-primary: #ffffff    /* Main text */
--text-secondary: #b8c5c5  /* Secondary text */
--text-muted: #7a8f8f      /* Muted text */
```

---

## 💰 Tokenomics

### Token Distribution

| Category | Percentage | Amount (1B Total Supply) | Purpose |
|----------|-----------|--------------------------|---------|
| **Charity** | 50% | 500,000,000 STP | Planet preservation, cleanup, support for churches, schools, students, education |
| **Liquidity** | 20% | 200,000,000 STP | Ensuring stable trading and market liquidity |
| **Team & Development** | 15% | 150,000,000 STP | Continuous platform development and team compensation |
| **Investors** | 10% | 100,000,000 STP | Early supporters and strategic partners |
| **Airdrops & Rewards** | 5% | 50,000,000 STP | Community rewards and marketing campaigns |

### Token Details

- **Token Name**: Save The Planet Token
- **Symbol**: STP
- **Total Supply**: 1,000,000,000 (1 Billion)
- **Blockchain**: BNB Smart Chain (BSC)
- **Token Standard**: BEP-20
- **Contract Address**: `0xb5048eed5a28b4077e58b2e96de44d6fb607b7da3`
- **Main Wallet**: `0x5a51FE7Aa3A8Efb25aEd5867fb91b1BEFD9Cc4D4`
- **Charity Fund Wallet**: `0xB8d0897cC908d0ddCcD4Ad19F781B2211D3dbA64`

---

## 📁 Project Structure

```
save-the-planet-token/
│
├── index.html              # Main HTML file
│
├── css/
│   └── style.css          # Main stylesheet with all styles
│
├── js/
│   └── main.js            # Main JavaScript file with all functionality
│
├── assets/                # (To be added)
│   ├── images/
│   ├── icons/
│   └── documents/
│
└── README.md              # This file
```

---

## 🚀 Installation & Usage

### Quick Start (No Installation Required!)

The website is a static HTML/CSS/JavaScript project. Simply:

1. **Download the project files**
2. **Open `index.html`** in any modern web browser (Chrome, Firefox, Safari, Edge)
3. **Enjoy!** The website is fully functional without any build process

### Local Development (Recommended)

For the best development experience:

1. **Clone or Download the Project**
   ```bash
   git clone [repository-url]
   cd save-the-planet-token
   ```

2. **Use a Local Server**
   
   Using Python:
   ```bash
   python -m http.server 8000
   # Open http://localhost:8000
   ```
   
   Using Node.js:
   ```bash
   npx http-server
   # Open http://localhost:8080
   ```
   
   Using VS Code:
   - Install "Live Server" extension
   - Right-click on `index.html` > Open with Live Server

3. **View in Browser**
   - Navigate to `http://localhost:8000` (or your server's address)
   - All animations and features will work perfectly!

### Deployment

The project is ready for deployment to any static hosting service:

- **Netlify**: Drag & drop the project folder
- **Vercel**: Connect your GitHub repository
- **GitHub Pages**: Enable in repository settings
- **AWS S3**: Upload to S3 bucket with static website hosting

---

## 🗺 Roadmap

### Q1 2024 ✅ (Completed)
- [x] Whitepaper release
- [x] Smart contract development
- [x] Website and social media launch
- [x] Community building

### Q2 2024 ✅ (Completed)
- [x] Private sale for early investors
- [x] Public presale launch
- [x] DEX listing preparation
- [x] First eco-project partnership

### Q3 2024 🔄 (In Progress)
- [ ] Uniswap listing
- [ ] PancakeSwap integration
- [ ] CMC & CoinGecko listing
- [ ] Launch first reforestation project

### Q4 2024 (Planned)
- [ ] Mobile app launch
- [ ] NFT collection for eco-heroes
- [ ] Major CEX listings
- [ ] Partnership with 10+ NGOs

### Q1 2025 (Future)
- [ ] 1 million trees planted
- [ ] DAO governance implementation
- [ ] Cross-chain bridge deployment
- [ ] International partnerships

---

## 👥 Team

### Vladimir - Founder & CEO
Visionary entrepreneur with 10+ years in blockchain technology and environmental activism. Passionate about creating sustainable solutions for global challenges.

### Full Team
- **Gennady** - Co-Founder: Strategic development and ecosystem expansion
- **Svetlana** - PR & Social Programs: Community engagement and charity partnerships  
- **Andrey** - Technology & Infrastructure: Platform security and scalability
- **Dominic** - Design & Marketing: Visual identity and brand communication

**United by one goal: To improve the world**

---

## 🤝 Contributing

We welcome contributions from the community! Here's how you can help:

### How to Contribute

1. **Report Bugs**: Open an issue describing the bug
2. **Suggest Features**: Share your ideas for improvements
3. **Submit Pull Requests**: 
   - Fork the repository
   - Create a feature branch
   - Make your changes
   - Submit a pull request

### Development Guidelines

- Follow existing code style and conventions
- Test your changes across different browsers and devices
- Update documentation for new features
- Ensure responsive design on all screen sizes

---

## 📞 Contact & Social Media

### Resources
- **Whitepaper**: https://savhukvladimir9-jpg.github.io/savetheplanet-project/STP_Whitepaper.pdf
- **BSCScan**: https://bscscan.com/token/0xb5048eed5a28b4077e58b2e96de44d6fb607b7da3

### Community
- **Telegram**: https://t.me/saveplanettoken
- **X (Twitter)**: https://x.com/stpsaveplanet
- **Instagram**: https://www.instagram.com/stp.token
- **Facebook**: https://www.facebook.com/groups/1354372396064529

### Contact
- **Email**: savhukvladimir9@gmail.com

---

## 🔐 Security & Audits

- Smart contract audit: *[Pending]*
- Security measures: *[To be documented]*
- Bug bounty program: *[Coming soon]*

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

## 🌟 Acknowledgments

- Inspired by leading crypto projects: Starknet, Optimism, Arbitrum
- Thanks to the open-source community for amazing tools and libraries
- Special thanks to all early supporters and environmental partners

---

## 📊 Project Status

**Current Version**: 1.0.0  
**Status**: Active Development  
**Last Updated**: December 2024

### Website Status
- ✅ Landing page completed
- ✅ Responsive design implemented
- ✅ Animations and interactions ready
- ✅ Tokenomics visualization complete
- ⏳ Smart contract integration pending
- ⏳ Wallet connection feature pending
- ⏳ Token purchase functionality pending

---

## 🎯 Recommended Next Steps

1. **Smart Contract Development**
   - Deploy ERC-20 token contract
   - Implement security measures
   - Conduct third-party audit

2. **Wallet Integration**
   - Add MetaMask connection
   - Implement WalletConnect
   - Support multiple wallets (Coinbase, Trust Wallet)

3. **Token Purchase Feature**
   - Build presale/ICO interface
   - Integrate payment gateways
   - Implement referral system

4. **Backend Development**
   - Create admin dashboard
   - Build newsletter subscription system
   - Implement analytics tracking

5. **Content Enhancement**
   - Professional photography
   - Team member photos
   - Project impact reports

6. **Marketing Materials**
   - Whitepaper design
   - Pitch deck
   - Press kit

---

<div align="center">

### 🌍 Together, We Can Save Our Planet 🌱

**Each token is not just an investment - it's a commitment to our planet's future.**

[Buy STP Now](#) • [Read Whitepaper](#) • [Join Community](#)

---

Made with 💚 by the Save The Planet Token Team

</div>