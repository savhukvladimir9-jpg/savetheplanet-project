# 🎨 Customization Guide - Save The Planet Token

This guide will help you customize the website to match your own crypto project's branding and content.

---

## 🎯 Quick Customization Checklist

- [ ] Update project name and tagline
- [ ] Change color scheme
- [ ] Replace tokenomics data
- [ ] Update team information
- [ ] Modify roadmap milestones
- [ ] Add your own content
- [ ] Update social media links
- [ ] Change token statistics
- [ ] Replace logo/favicon

---

## 🎨 1. Changing Colors

### Location: `css/style.css` (Lines 10-30)

```css
:root {
    /* PRIMARY COLORS - Change these for your brand */
    --primary-bg: #0a1f1f;        /* Main background color */
    --secondary-bg: #0d2828;      /* Secondary background */
    --tertiary-bg: #153838;       /* Card backgrounds */
    
    /* ACCENT COLORS - Your brand colors */
    --accent-gold: #f4d03f;       /* Primary accent (buttons, highlights) */
    --accent-yellow: #ffe66d;     /* Secondary accent */
    --accent-green: #2ecc71;      /* Success/eco indicators */
    --accent-teal: #1abc9c;       /* Additional highlights */
    
    /* TEXT COLORS */
    --text-primary: #ffffff;      /* Main text */
    --text-secondary: #b8c5c5;    /* Secondary text */
    --text-muted: #7a8f8f;        /* Muted text */
}
```

### Example: Blue & Purple Theme

```css
:root {
    --primary-bg: #0a0e27;
    --secondary-bg: #1a1f3a;
    --tertiary-bg: #2a2f4a;
    --accent-gold: #6366f1;       /* Indigo */
    --accent-yellow: #818cf8;     /* Light indigo */
    --accent-green: #34d399;      /* Green */
    --accent-teal: #60a5fa;       /* Blue */
}
```

---

## 📝 2. Updating Content

### Project Name & Tagline

**Location: `index.html`**

```html
<!-- Line ~40: Navigation Logo -->
<div class="logo">
    <i class="fas fa-globe-americas"></i>
    <span>STP</span> <!-- Change to your token symbol -->
</div>

<!-- Line ~70: Hero Title -->
<h1 class="hero-title">SAVE THE PLANET TOKEN</h1> <!-- Your project name -->
<p class="hero-subtitle">Each Token Saves a Life on Earth</p> <!-- Your tagline -->
```

### Statistics Counter

**Location: `index.html` (Lines ~95-115)**

```html
<div class="hero-stats">
    <div class="stat-item" data-aos="fade-up" data-aos-delay="100">
        <div class="stat-value" data-count="50000">0</div> <!-- Change number -->
        <div class="stat-label">Trees Planted</div> <!-- Change label -->
    </div>
    <!-- Repeat for other stats -->
</div>
```

---

## 💰 3. Tokenomics Customization

### Update Distribution Data

**Location: `js/main.js` (Lines ~180-210)**

```javascript
new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: [
            'Eco-Fund (50%)',           // Change label
            'Liquidity Pool (20%)',     // Change label
            'Development & Team (15%)', // Change label
            'Investors (10%)',          // Change label
            'Airdrops & Community (5%)' // Change label
        ],
        datasets: [{
            data: [50, 20, 15, 10, 5],  // Change percentages (must sum to 100)
            // Colors remain the same or customize
        }]
    }
});
```

### Token Details Cards

**Location: `index.html` (Lines ~280-340)**

```html
<div class="token-detail-card">
    <div class="detail-icon eco-fund">
        <i class="fas fa-heart"></i> <!-- Change icon -->
    </div>
    <div class="detail-content">
        <div class="detail-header">
            <h4>Eco-Fund</h4> <!-- Change title -->
            <span class="percentage">50%</span> <!-- Change percentage -->
        </div>
        <p>Charity & Planet Rescue initiatives worldwide</p> <!-- Change description -->
    </div>
</div>
```

### Token Information

**Location: `index.html` (Lines ~360-395)**

```html
<div class="info-card">
    <h4>Total Supply</h4>
    <p class="info-value">1,000,000,000</p> <!-- Change value -->
</div>
<div class="info-card">
    <h4>Token Symbol</h4>
    <p class="info-value">STP</p> <!-- Change symbol -->
</div>
<div class="info-card">
    <h4>Blockchain</h4>
    <p class="info-value">Ethereum</p> <!-- Change blockchain -->
</div>
```

---

## 🗺️ 4. Roadmap Updates

**Location: `index.html` (Lines ~410-520)**

### Adding a New Milestone

```html
<div class="timeline-item" data-aos="fade-up" data-aos-delay="600">
    <div class="timeline-marker"></div> <!-- completed, current, or empty -->
    <div class="timeline-content">
        <div class="timeline-date">Q2 2025</div> <!-- Your quarter -->
        <h3>Your Milestone Title</h3> <!-- Your title -->
        <ul>
            <li>Task 1</li> <!-- Your tasks -->
            <li>Task 2</li>
            <li>Task 3</li>
        </ul>
    </div>
</div>
```

### Milestone Status Classes
- `completed`: Green checkmark (finished)
- `current`: Gold pulsing (in progress)
- Empty: Gray (upcoming)

---

## 👥 5. Team Section

**Location: `index.html` (Lines ~540-610)**

### Adding Team Members

```html
<div class="team-member" data-aos="fade-up" data-aos-delay="100">
    <div class="member-image">
        <div class="member-avatar">
            <i class="fas fa-user-circle"></i> <!-- Icon or add image tag -->
        </div>
        <div class="member-social">
            <a href="https://linkedin.com/in/yourprofile" aria-label="LinkedIn">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="https://twitter.com/yourhandle" aria-label="Twitter">
                <i class="fab fa-twitter"></i>
            </a>
        </div>
    </div>
    <div class="member-info">
        <h3>Your Name</h3> <!-- Team member name -->
        <p class="member-role">Your Role</p> <!-- Role/title -->
        <p class="member-bio">
            Your bio description here... <!-- Biography -->
        </p>
    </div>
</div>
```

### Adding Real Photos

Replace the icon with an image:

```html
<div class="member-avatar">
    <img src="assets/images/team/member1.jpg" alt="Team Member Name">
</div>
```

Then add this CSS:

```css
.member-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}
```

---

## 🔗 6. Social Media Links

**Location: `index.html` (Lines ~640-675)**

```html
<!-- Contact Section -->
<a href="https://t.me/yourchannel" class="social-link telegram">
    <i class="fab fa-telegram"></i>
    <span>Telegram</span>
</a>

<!-- Footer Section -->
<li><a href="https://t.me/yourchannel">Telegram</a></li>
<li><a href="https://discord.gg/yourserver">Discord</a></li>
<li><a href="https://twitter.com/yourhandle">Twitter</a></li>
```

---

## 🎭 7. Icons & Logos

### Favicon

**Location: `index.html` (Line ~25)**

Current: Emoji-based SVG favicon

```html
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🌍</text></svg>">
```

Replace with your own:

```html
<link rel="icon" type="image/png" href="assets/images/favicon.png">
```

### Logo

**Location: `index.html` (Lines ~40, ~685)**

Current: Icon + Text

```html
<div class="logo">
    <i class="fas fa-globe-americas"></i> <!-- Change icon -->
    <span>STP</span> <!-- Change text -->
</div>
```

Replace with image:

```html
<div class="logo">
    <img src="assets/images/logo.png" alt="Logo" style="height: 40px;">
</div>
```

---

## 📧 8. Newsletter Form Action

**Location: `js/main.js` (Lines ~240-280)**

### Connect to Email Service

Replace the console.log with actual API call:

```javascript
// Current (demo):
console.log('Newsletter subscription:', email);

// Replace with:
fetch('https://your-api.com/subscribe', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email: email })
})
.then(response => response.json())
.then(data => {
    console.log('Subscribed:', data);
})
.catch(error => {
    console.error('Error:', error);
});
```

Popular services:
- **Mailchimp API**
- **SendGrid**
- **ConvertKit**
- **Netlify Forms**

---

## 🔢 9. Token Price Animation

**Location: `js/main.js` (Lines ~310-340)**

### Set Initial Price

```javascript
// Current demo price
const priceElement = document.querySelector('.token-price');
priceElement.textContent = '$0.00025'; // Change this

// For real-time prices, connect to API:
async function updateTokenPrice() {
    const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=your-token&vs_currencies=usd');
    const data = await response.json();
    priceElement.textContent = `$${data['your-token'].usd}`;
}
```

---

## 📱 10. Meta Tags & SEO

**Location: `index.html` (Lines ~5-30)**

```html
<!-- Update these for your project -->
<meta name="description" content="Your project description">
<meta name="keywords" content="your, keywords, here">
<meta name="author" content="Your Team Name">

<!-- Open Graph (Facebook, LinkedIn) -->
<meta property="og:title" content="Your Project Name">
<meta property="og:description" content="Your description">
<meta property="og:image" content="https://yoursite.com/preview-image.jpg">
<meta property="og:url" content="https://yoursite.com">

<!-- Twitter Card -->
<meta property="twitter:title" content="Your Project Name">
<meta property="twitter:description" content="Your description">
<meta property="twitter:image" content="https://yoursite.com/preview-image.jpg">
```

---

## 🎬 11. Animations & Effects

### Adjusting Animation Speed

**Location: `css/style.css`**

```css
/* Global transition speeds */
:root {
    --transition-fast: 0.2s ease;    /* Hover effects */
    --transition-normal: 0.3s ease;  /* General animations */
    --transition-slow: 0.5s ease;    /* Large movements */
}
```

### AOS Animation Settings

**Location: `js/main.js` (Lines ~15-25)**

```javascript
AOS.init({
    duration: 1000,        // Animation duration (ms)
    easing: 'ease-out-cubic', // Easing function
    once: true,            // Animate only once
    offset: 100           // Offset from viewport
});
```

---

## 🖼️ 12. Adding Custom Sections

### Template for New Section

```html
<section class="your-section-name" id="your-id">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <div class="section-badge">Your Badge</div>
            <h2 class="section-title">Your Title</h2>
            <p class="section-description">Your description</p>
        </div>
        
        <div class="your-content">
            <!-- Your custom content here -->
        </div>
    </div>
</section>
```

Add corresponding CSS:

```css
.your-section-name {
    background: var(--secondary-bg);
    /* Add your styles */
}
```

Add to navigation:

```html
<li><a href="#your-id" class="nav-link">Your Section</a></li>
```

---

## 🛠️ 13. Advanced Customizations

### Custom Fonts

Replace Inter font in `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=YourFont:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

Update CSS:

```css
:root {
    --font-primary: 'YourFont', sans-serif;
}
```

### Custom Chart Colors

**Location: `js/main.js` (Lines ~190-210)**

```javascript
backgroundColor: [
    'rgba(231, 76, 60, 0.8)',   // Red - Change RGB values
    'rgba(52, 152, 219, 0.8)',  // Blue
    'rgba(155, 89, 182, 0.8)',  // Purple
    'rgba(241, 196, 15, 0.8)',  // Yellow
    'rgba(46, 204, 113, 0.8)'   // Green
]
```

---

## 📚 Common Customization Scenarios

### Scenario 1: Gaming Token
- Change colors to neon (purple, cyan, pink)
- Replace globe icon with game controller
- Update content to gaming terminology
- Add game-specific sections

### Scenario 2: DeFi Protocol
- Professional blue/white theme
- Replace environmental content with financial
- Add APY calculator section
- Integrate with DeFi protocols

### Scenario 3: NFT Project
- Vibrant gradient colors
- Add NFT gallery section
- Replace tokenomics with rarity charts
- Add minting countdown timer

---

## 🐛 Troubleshooting

### Issue: Animations not working
**Solution**: Ensure AOS library is loaded properly

```html
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
```

### Issue: Chart not displaying
**Solution**: Check if Chart.js is loaded and canvas element exists

```html
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
```

### Issue: Mobile menu not working
**Solution**: Ensure JavaScript is loading after DOM

```javascript
document.addEventListener('DOMContentLoaded', function() {
    // Your code here
});
```

---

## 💡 Tips for Success

1. **Test Responsiveness**: Check on multiple devices
2. **Optimize Images**: Compress before uploading
3. **Validate Code**: Use W3C validators
4. **Check Performance**: Use Lighthouse audit
5. **Cross-Browser**: Test on Chrome, Firefox, Safari
6. **Accessibility**: Ensure keyboard navigation works

---

## 📞 Need Help?

If you need assistance with customization:

1. Check the code comments in each file
2. Refer to library documentation (Chart.js, AOS)
3. Use browser DevTools for debugging
4. Validate HTML/CSS online

---

<div align="center">

## 🎨 Make it yours! 

**This template is your canvas - customize it to match your vision.**

</div>