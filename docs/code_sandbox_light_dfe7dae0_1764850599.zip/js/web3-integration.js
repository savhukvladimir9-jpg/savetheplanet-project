/**
 * Web3 Integration for Save The Planet Token (STP)
 * BNB Smart Chain (BSC) - BEP-20 Token
 * 
 * Contract Address: 0xb5048eed5a28b4077e58b2e96de44d6fb607b7da3
 * Network: BSC Mainnet (Chain ID: 56)
 */

// ============================================
// CONTRACT CONFIGURATION
// ============================================

const STP_CONFIG = {
    // Contract address on BSC
    contractAddress: '0xb5048eed5a28b4077e58b2e96de44d6fb607b7da3',
    
    // Network configuration
    chainId: '0x38', // 56 in hex (BSC Mainnet)
    chainIdDecimal: 56,
    networkName: 'BNB Smart Chain',
    rpcUrl: 'https://bsc-dataseed1.binance.org',
    blockExplorerUrl: 'https://bscscan.com',
    nativeCurrency: {
        name: 'BNB',
        symbol: 'BNB',
        decimals: 18
    },
    
    // Token configuration
    token: {
        name: 'Save The Planet Token',
        symbol: 'STP',
        decimals: 18,
        totalSupply: '1000000000', // 1 billion
        image: 'https://www.genspark.ai/api/files/s/VmZ4g06h'
    },
    
    // PancakeSwap router
    pancakeSwapRouter: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
    
    // PancakeSwap exchange URL
    pancakeSwapUrl: 'https://pancakeswap.finance/swap'
};

// ============================================
// MINIMAL BEP-20 ABI (for read operations)
// ============================================

const BEP20_ABI = [
    // Read functions
    {
        "constant": true,
        "inputs": [],
        "name": "name",
        "outputs": [{"name": "", "type": "string"}],
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "totalSupply",
        "outputs": [{"name": "", "type": "uint256"}],
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function"
    }
];

// ============================================
// WEB3 STATE MANAGEMENT
// ============================================

const web3State = {
    provider: null,
    web3: null,
    contract: null,
    account: null,
    balance: '0',
    chainId: null,
    isConnected: false
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Format token amount with decimals
 */
function formatTokenAmount(amount, decimals = 18) {
    try {
        const divisor = Math.pow(10, decimals);
        const formatted = (amount / divisor).toFixed(2);
        return formatted.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    } catch (error) {
        console.error('Error formatting token amount:', error);
        return '0.00';
    }
}

/**
 * Format wallet address (short version)
 */
function formatAddress(address) {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}

/**
 * Copy text to clipboard
 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showNotification('Copied to clipboard!', 'success');
    } catch (error) {
        console.error('Failed to copy:', error);
        showNotification('Failed to copy', 'error');
    }
}

/**
 * Show notification message
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `web3-notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => notification.classList.add('show'), 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ============================================
// WEB3 CONNECTION FUNCTIONS
// ============================================

/**
 * Check if MetaMask is installed
 */
function isMetaMaskInstalled() {
    return typeof window.ethereum !== 'undefined';
}

/**
 * Switch to BSC network
 */
async function switchToBSC() {
    try {
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: STP_CONFIG.chainId }],
        });
        return true;
    } catch (switchError) {
        // Chain not added yet
        if (switchError.code === 4902) {
            try {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: STP_CONFIG.chainId,
                        chainName: STP_CONFIG.networkName,
                        nativeCurrency: STP_CONFIG.nativeCurrency,
                        rpcUrls: [STP_CONFIG.rpcUrl],
                        blockExplorerUrls: [STP_CONFIG.blockExplorerUrl]
                    }]
                });
                return true;
            } catch (addError) {
                console.error('Error adding BSC network:', addError);
                showNotification('Failed to add BSC network', 'error');
                return false;
            }
        }
        console.error('Error switching to BSC:', switchError);
        showNotification('Failed to switch to BSC network', 'error');
        return false;
    }
}

/**
 * Connect wallet
 */
async function connectWallet() {
    if (!isMetaMaskInstalled()) {
        showNotification('Please install MetaMask or Trust Wallet!', 'error');
        window.open('https://metamask.io/download/', '_blank');
        return false;
    }
    
    try {
        // Request account access
        const accounts = await window.ethereum.request({
            method: 'eth_requestAccounts'
        });
        
        if (accounts.length === 0) {
            throw new Error('No accounts found');
        }
        
        // Get chain ID
        const chainId = await window.ethereum.request({
            method: 'eth_chainId'
        });
        
        // Check if on BSC network
        if (chainId !== STP_CONFIG.chainId) {
            const switched = await switchToBSC();
            if (!switched) return false;
        }
        
        // Update state
        web3State.account = accounts[0];
        web3State.chainId = chainId;
        web3State.isConnected = true;
        
        // Initialize Web3
        await initializeWeb3();
        
        // Update UI
        updateWalletUI();
        
        // Get balance
        await updateBalance();
        
        showNotification('Wallet connected successfully!', 'success');
        return true;
        
    } catch (error) {
        console.error('Error connecting wallet:', error);
        showNotification('Failed to connect wallet', 'error');
        return false;
    }
}

/**
 * Disconnect wallet
 */
function disconnectWallet() {
    web3State.account = null;
    web3State.balance = '0';
    web3State.isConnected = false;
    updateWalletUI();
    showNotification('Wallet disconnected', 'info');
}

/**
 * Initialize Web3 with ethers.js (using CDN)
 */
async function initializeWeb3() {
    try {
        // Using ethers.js (will be loaded via CDN in HTML)
        if (typeof ethers === 'undefined') {
            throw new Error('Ethers.js not loaded');
        }
        
        web3State.provider = new ethers.providers.Web3Provider(window.ethereum);
        web3State.contract = new ethers.Contract(
            STP_CONFIG.contractAddress,
            BEP20_ABI,
            web3State.provider
        );
        
        return true;
    } catch (error) {
        console.error('Error initializing Web3:', error);
        return false;
    }
}

/**
 * Get STP token balance
 */
async function updateBalance() {
    if (!web3State.isConnected || !web3State.contract || !web3State.account) {
        return;
    }
    
    try {
        const balance = await web3State.contract.balanceOf(web3State.account);
        web3State.balance = balance.toString();
        updateBalanceUI();
    } catch (error) {
        console.error('Error getting balance:', error);
        web3State.balance = '0';
        updateBalanceUI();
    }
}

// ============================================
// UI UPDATE FUNCTIONS
// ============================================

/**
 * Update wallet connection UI
 */
function updateWalletUI() {
    const connectBtn = document.getElementById('connectWalletBtn');
    const walletInfo = document.getElementById('walletInfo');
    const walletAddress = document.getElementById('walletAddress');
    
    if (!connectBtn) return;
    
    if (web3State.isConnected) {
        connectBtn.textContent = 'Connected';
        connectBtn.classList.add('connected');
        
        if (walletAddress) {
            walletAddress.textContent = formatAddress(web3State.account);
        }
        
        if (walletInfo) {
            walletInfo.style.display = 'flex';
        }
    } else {
        connectBtn.textContent = 'Connect Wallet';
        connectBtn.classList.remove('connected');
        
        if (walletInfo) {
            walletInfo.style.display = 'none';
        }
    }
}

/**
 * Update balance display
 */
function updateBalanceUI() {
    const balanceElement = document.getElementById('stpBalance');
    if (balanceElement) {
        const formattedBalance = formatTokenAmount(web3State.balance, STP_CONFIG.token.decimals);
        balanceElement.textContent = `${formattedBalance} STP`;
    }
}

// ============================================
// TOKEN INTERACTION FUNCTIONS
// ============================================

/**
 * Add STP token to wallet
 */
async function addTokenToWallet() {
    if (!isMetaMaskInstalled()) {
        showNotification('Please install MetaMask first!', 'error');
        return;
    }
    
    try {
        const wasAdded = await window.ethereum.request({
            method: 'wallet_watchAsset',
            params: {
                type: 'ERC20',
                options: {
                    address: STP_CONFIG.contractAddress,
                    symbol: STP_CONFIG.token.symbol,
                    decimals: STP_CONFIG.token.decimals,
                    image: STP_CONFIG.token.image
                }
            }
        });
        
        if (wasAdded) {
            showNotification('STP token added to wallet!', 'success');
        }
    } catch (error) {
        console.error('Error adding token:', error);
        showNotification('Failed to add token', 'error');
    }
}

/**
 * Open PancakeSwap for buying STP
 */
function buyOnPancakeSwap() {
    const url = `${STP_CONFIG.pancakeSwapUrl}?outputCurrency=${STP_CONFIG.contractAddress}`;
    window.open(url, '_blank');
}

/**
 * Open BSCScan contract page
 */
function viewOnBSCScan() {
    const url = `${STP_CONFIG.blockExplorerUrl}/token/${STP_CONFIG.contractAddress}`;
    window.open(url, '_blank');
}

// ============================================
// EVENT LISTENERS
// ============================================

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Wallet connection
    const connectBtn = document.getElementById('connectWalletBtn');
    if (connectBtn) {
        connectBtn.addEventListener('click', connectWallet);
    }
    
    // Add token button
    const addTokenBtn = document.getElementById('addTokenBtn');
    if (addTokenBtn) {
        addTokenBtn.addEventListener('click', addTokenToWallet);
    }
    
    // Buy on PancakeSwap
    const buyButtons = document.querySelectorAll('.btn-buy-pancake, .buy-pancake-btn');
    buyButtons.forEach(btn => {
        btn.addEventListener('click', buyOnPancakeSwap);
    });
    
    // View on BSCScan
    const bscButtons = document.querySelectorAll('.view-bscscan-btn');
    bscButtons.forEach(btn => {
        btn.addEventListener('click', viewOnBSCScan);
    });
    
    // MetaMask events
    if (window.ethereum) {
        // Account changed
        window.ethereum.on('accountsChanged', (accounts) => {
            if (accounts.length === 0) {
                disconnectWallet();
            } else {
                web3State.account = accounts[0];
                updateWalletUI();
                updateBalance();
            }
        });
        
        // Chain changed
        window.ethereum.on('chainChanged', (chainId) => {
            if (chainId !== STP_CONFIG.chainId) {
                showNotification('Please switch to BSC network', 'error');
            }
            window.location.reload();
        });
    }
}

// ============================================
// INITIALIZATION
// ============================================

/**
 * Initialize Web3 integration
 */
async function initializeWeb3Integration() {
    console.log('🌍 Initializing Web3 Integration for STP Token...');
    
    // Setup event listeners
    setupEventListeners();
    
    // Check if already connected
    if (isMetaMaskInstalled() && window.ethereum.selectedAddress) {
        await connectWallet();
    }
    
    console.log('✅ Web3 Integration initialized');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeWeb3Integration);
} else {
    initializeWeb3Integration();
}

// Export for use in other scripts
window.STPWeb3 = {
    connectWallet,
    disconnectWallet,
    addTokenToWallet,
    buyOnPancakeSwap,
    viewOnBSCScan,
    getBalance: () => web3State.balance,
    getAccount: () => web3State.account,
    isConnected: () => web3State.isConnected
};
