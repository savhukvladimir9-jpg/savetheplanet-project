// ===================================
// SAVE THE PLANET TOKEN - STP
// Main JavaScript File
// ===================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ===================================
    // INITIALIZATION
    // ===================================
    
    initAOS();
    initNavigation();
    initScrollEffects();
    initCounterAnimation();
    initTokenomicsChart();
    initNewsletterForm();
    
    // ===================================
    // AOS ANIMATION INITIALIZATION
    // ===================================
    
    function initAOS() {
        AOS.init({
            duration: 1000,
            easing: 'ease-out-cubic',
            once: true,
            offset: 100
        });
    }
    
    // ===================================
    // NAVIGATION
    // ===================================
    
    function initNavigation() {
        const navbar = document.getElementById('navbar');
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('navMenu');
        const navLinks = document.querySelectorAll('.nav-link');
        
        // Sticky navbar on scroll
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
        
        // Mobile menu toggle
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
            
            // Animate hamburger icon
            const spans = hamburger.querySelectorAll('span');
            if (hamburger.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
        
        // Smooth scroll and active link highlighting
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    // Close mobile menu
                    navMenu.classList.remove('active');
                    hamburger.classList.remove('active');
                    
                    // Reset hamburger icon
                    const spans = hamburger.querySelectorAll('span');
                    spans[0].style.transform = 'none';
                    spans[1].style.opacity = '1';
                    spans[2].style.transform = 'none';
                    
                    // Smooth scroll to section
                    const offsetTop = targetSection.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                    
                    // Update active link
                    navLinks.forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
                }
            });
        });
        
        // Update active link on scroll
        window.addEventListener('scroll', () => {
            let current = '';
            const sections = document.querySelectorAll('section');
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (window.pageYOffset >= sectionTop - 150) {
                    current = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });
    }
    
    // ===================================
    // SCROLL EFFECTS
    // ===================================
    
    function initScrollEffects() {
        // Parallax effect for hero background
        const heroBackground = document.querySelector('.hero-background');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            if (heroBackground) {
                heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
            }
        });
        
        // Scroll indicator hide on scroll
        const scrollIndicator = document.querySelector('.scroll-indicator');
        if (scrollIndicator) {
            window.addEventListener('scroll', () => {
                if (window.scrollY > 300) {
                    scrollIndicator.style.opacity = '0';
                } else {
                    scrollIndicator.style.opacity = '1';
                }
            });
        }
    }
    
    // ===================================
    // COUNTER ANIMATION
    // ===================================
    
    function initCounterAnimation() {
        const counters = document.querySelectorAll('.stat-value');
        const speed = 200; // Animation speed
        
        const animateCounter = (counter) => {
            const target = +counter.getAttribute('data-count');
            const count = +counter.innerText;
            const increment = target / speed;
            
            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(() => animateCounter(counter), 1);
            } else {
                counter.innerText = target.toLocaleString();
            }
        };
        
        // Intersection Observer for counter animation
        const observerOptions = {
            threshold: 0.5
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const counter = entry.target;
                    if (!counter.classList.contains('animated')) {
                        counter.classList.add('animated');
                        animateCounter(counter);
                    }
                }
            });
        }, observerOptions);
        
        counters.forEach(counter => observer.observe(counter));
    }
    
    // ===================================
    // TOKENOMICS CHART (Chart.js)
    // ===================================
    
    function initTokenomicsChart() {
        const ctx = document.getElementById('tokenomicsChart');
        
        if (ctx) {
            // Create gradient for chart
            const gradient1 = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
            gradient1.addColorStop(0, 'rgba(231, 76, 60, 0.8)');
            gradient1.addColorStop(1, 'rgba(231, 76, 60, 0.4)');
            
            const gradient2 = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
            gradient2.addColorStop(0, 'rgba(52, 152, 219, 0.8)');
            gradient2.addColorStop(1, 'rgba(52, 152, 219, 0.4)');
            
            const gradient3 = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
            gradient3.addColorStop(0, 'rgba(155, 89, 182, 0.8)');
            gradient3.addColorStop(1, 'rgba(155, 89, 182, 0.4)');
            
            const gradient4 = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
            gradient4.addColorStop(0, 'rgba(241, 196, 15, 0.8)');
            gradient4.addColorStop(1, 'rgba(241, 196, 15, 0.4)');
            
            const gradient5 = ctx.getContext('2d').createLinearGradient(0, 0, 0, 400);
            gradient5.addColorStop(0, 'rgba(46, 204, 113, 0.8)');
            gradient5.addColorStop(1, 'rgba(46, 204, 113, 0.4)');
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: [
                        'Charity (50%)',
                        'Liquidity (20%)',
                        'Team & Development (15%)',
                        'Investors (10%)',
                        'Airdrops & Rewards (5%)'
                    ],
                    datasets: [{
                        data: [50, 20, 15, 10, 5],
                        backgroundColor: [
                            gradient1,
                            gradient2,
                            gradient3,
                            gradient4,
                            gradient5
                        ],
                        borderColor: [
                            '#e74c3c',
                            '#3498db',
                            '#9b59b6',
                            '#f1c40f',
                            '#2ecc71'
                        ],
                        borderWidth: 2,
                        hoverOffset: 20
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                color: '#ffffff',
                                font: {
                                    size: 14,
                                    family: 'Inter'
                                },
                                padding: 20,
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(10, 31, 31, 0.9)',
                            titleColor: '#f4d03f',
                            bodyColor: '#ffffff',
                            borderColor: '#f4d03f',
                            borderWidth: 1,
                            padding: 12,
                            displayColors: true,
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.parsed;
                                    return ` ${label}: ${value}%`;
                                }
                            }
                        }
                    },
                    animation: {
                        animateRotate: true,
                        animateScale: true,
                        duration: 2000,
                        easing: 'easeInOutQuart'
                    }
                }
            });
        }
    }
    
    // ===================================
    // NEWSLETTER FORM
    // ===================================
    
    function initNewsletterForm() {
        const form = document.querySelector('.newsletter-form');
        
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                
                const input = form.querySelector('input[type="email"]');
                const button = form.querySelector('button');
                const email = input.value;
                
                // Validate email
                if (validateEmail(email)) {
                    // Show success message
                    button.textContent = 'Subscribed! ✓';
                    button.style.background = 'linear-gradient(135deg, #2ecc71 0%, #27ae60 100%)';
                    input.value = '';
                    
                    // Reset button after 3 seconds
                    setTimeout(() => {
                        button.textContent = 'Subscribe';
                        button.style.background = '';
                    }, 3000);
                    
                    // You can add your newsletter subscription logic here
                    console.log('Newsletter subscription:', email);
                } else {
                    // Show error message
                    button.textContent = 'Invalid Email';
                    button.style.background = 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)';
                    
                    setTimeout(() => {
                        button.textContent = 'Subscribe';
                        button.style.background = '';
                    }, 2000);
                }
            });
        }
    }
    
    // Email validation helper
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // ===================================
    // FLOATING CARD INTERACTION
    // ===================================
    
    const floatingCard = document.querySelector('.floating-card');
    if (floatingCard) {
        floatingCard.addEventListener('mouseenter', function() {
            this.style.animationPlayState = 'paused';
            this.style.transform = 'scale(1.05) translateY(-10px)';
        });
        
        floatingCard.addEventListener('mouseleave', function() {
            this.style.animationPlayState = 'running';
            this.style.transform = '';
        });
    }
    
    // ===================================
    // TOKEN PRICE ANIMATION
    // ===================================
    
    function animateTokenPrice() {
        const priceElement = document.querySelector('.token-price');
        const changeElement = document.querySelector('.token-change');
        
        if (priceElement && changeElement) {
            setInterval(() => {
                // Simulate price change (for demo purposes)
                const currentPrice = parseFloat(priceElement.textContent.replace('$', ''));
                const change = (Math.random() - 0.5) * 0.00001;
                const newPrice = (currentPrice + change).toFixed(5);
                
                priceElement.textContent = `$${newPrice}`;
                
                // Update change percentage
                const changePercent = ((change / currentPrice) * 100).toFixed(1);
                if (changePercent > 0) {
                    changeElement.textContent = `+${changePercent}%`;
                    changeElement.className = 'token-change positive';
                    changeElement.style.color = '#2ecc71';
                } else {
                    changeElement.textContent = `${changePercent}%`;
                    changeElement.className = 'token-change negative';
                    changeElement.style.color = '#e74c3c';
                }
            }, 3000);
        }
    }
    
    animateTokenPrice();
    
    // ===================================
    // PARTICLE EFFECT ENHANCEMENT
    // ===================================
    
    function createParticles() {
        const particlesContainer = document.querySelector('.particles');
        if (!particlesContainer) return;
        
        // Create floating particles dynamically
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.cssText = `
                position: absolute;
                width: ${Math.random() * 4 + 1}px;
                height: ${Math.random() * 4 + 1}px;
                background: ${Math.random() > 0.5 ? '#f4d03f' : '#2ecc71'};
                border-radius: 50%;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                opacity: ${Math.random() * 0.5 + 0.2};
                animation: particle-float ${Math.random() * 10 + 5}s linear infinite;
            `;
            particlesContainer.appendChild(particle);
        }
        
        // Add particle animation if not exists
        if (!document.querySelector('#particle-animation')) {
            const style = document.createElement('style');
            style.id = 'particle-animation';
            style.textContent = `
                @keyframes particle-float {
                    0% {
                        transform: translateY(0) translateX(0);
                        opacity: 0;
                    }
                    10% {
                        opacity: 1;
                    }
                    90% {
                        opacity: 1;
                    }
                    100% {
                        transform: translateY(-100vh) translateX(${Math.random() * 100 - 50}px);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    createParticles();
    
    // ===================================
    // CARD HOVER EFFECTS
    // ===================================
    
    function initCardEffects() {
        const cards = document.querySelectorAll('.about-card, .token-detail-card, .team-member, .social-link');
        
        cards.forEach(card => {
            card.addEventListener('mouseenter', function(e) {
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                this.style.setProperty('--mouse-x', `${x}px`);
                this.style.setProperty('--mouse-y', `${y}px`);
            });
        });
    }
    
    initCardEffects();
    
    // ===================================
    // SMOOTH REVEAL ON SCROLL
    // ===================================
    
    function initScrollReveal() {
        const reveals = document.querySelectorAll('.timeline-item, .about-card, .token-detail-card');
        
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.15
        });
        
        reveals.forEach(reveal => {
            reveal.style.opacity = '0';
            reveal.style.transform = 'translateY(30px)';
            reveal.style.transition = 'all 0.6s ease';
            revealObserver.observe(reveal);
        });
    }
    
    initScrollReveal();
    
    // ===================================
    // LOADING ANIMATION
    // ===================================
    
    window.addEventListener('load', () => {
        document.body.style.opacity = '0';
        setTimeout(() => {
            document.body.style.transition = 'opacity 0.5s ease';
            document.body.style.opacity = '1';
        }, 100);
    });
    
    // ===================================
    // CONSOLE MESSAGE
    // ===================================
    
    console.log('%c🌍 Save The Planet Token (STP) ', 'background: #0a1f1f; color: #f4d03f; font-size: 20px; font-weight: bold; padding: 10px;');
    console.log('%cEach Token Saves a Life on Earth', 'color: #2ecc71; font-size: 14px;');
    console.log('%cWebsite developed with 💚 for a better planet', 'color: #b8c5c5; font-size: 12px;');
    
});

// ===================================
// UTILITY FUNCTIONS
// ===================================

// Debounce function for performance optimization
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Throttle function for scroll events
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Copy to clipboard function
function copyToClipboard(text) {
    // Create temporary textarea
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        document.execCommand('copy');
        
        // Show success message
        showCopyNotification('Address copied to clipboard!');
    } catch (err) {
        console.error('Failed to copy:', err);
        showCopyNotification('Failed to copy address', true);
    }
    
    document.body.removeChild(textarea);
}

// Show copy notification
function showCopyNotification(message, isError = false) {
    // Remove existing notifications
    const existing = document.querySelector('.copy-notification');
    if (existing) {
        existing.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'copy-notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${isError ? '#e74c3c' : '#2ecc71'};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        animation: slideIn 0.3s ease;
        font-weight: 500;
    `;
    
    // Add animation keyframes if not exists
    if (!document.querySelector('#copyNotificationStyles')) {
        const style = document.createElement('style');
        style.id = 'copyNotificationStyles';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(400px);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}