# 🚀 Deployment Guide - Save The Planet Token Website

Complete guide for deploying your STP website to production.

---

## 📋 Pre-Deployment Checklist

Before deploying, ensure:

- [x] All content is accurate and up-to-date
- [x] Contract addresses are verified
- [x] Social media links are working
- [x] Email address is correct
- [x] Website tested on multiple devices
- [x] All animations working properly
- [x] No console errors
- [x] Forms are functional

---

## 🌐 Deployment Options

### Option 1: Netlify (Recommended) ⭐

**Why Netlify?**
- Free tier available
- Automatic HTTPS
- Custom domain support
- Drag & drop deployment
- Continuous deployment from Git

**Steps:**

1. **Sign up for Netlify**
   - Go to https://www.netlify.com
   - Create free account

2. **Deploy via Drag & Drop**
   ```
   - Drag your project folder to Netlify dashboard
   - Wait for deployment (30 seconds)
   - Get your live URL: https://your-site.netlify.app
   ```

3. **Configure Custom Domain** (Optional)
   ```
   - Go to Domain settings
   - Add custom domain (e.g., stptoken.io)
   - Update DNS records at your domain registrar
   - Wait for DNS propagation (up to 24 hours)
   ```

4. **Setup Continuous Deployment** (Optional)
   ```
   - Connect GitHub repository
   - Enable automatic deployments
   - Every push to main branch = automatic deployment
   ```

**Netlify Configuration (`netlify.toml`):**
```toml
[build]
  publish = "."
  command = "echo 'No build needed'"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

### Option 2: Vercel

**Steps:**

1. **Sign up**: https://vercel.com
2. **Import Project**:
   ```
   - Click "New Project"
   - Import from GitHub or upload files
   - Configure: Framework Preset = "Other"
   - Deploy
   ```

3. **Custom Domain**:
   ```
   - Go to Project Settings > Domains
   - Add your domain
   - Update DNS records
   ```

**Vercel Configuration (`vercel.json`):**
```json
{
  "version": 2,
  "builds": [
    {
      "src": "index.html",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/$1"
    }
  ]
}
```

---

### Option 3: GitHub Pages

**Steps:**

1. **Create GitHub Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/stp-website.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   ```
   - Go to Repository Settings
   - Scroll to GitHub Pages section
   - Source: main branch / root
   - Save
   ```

3. **Access Your Site**
   ```
   https://YOUR_USERNAME.github.io/stp-website/
   ```

4. **Custom Domain** (Optional)
   ```
   - Add CNAME file with your domain
   - Configure DNS at domain registrar
   ```

---

### Option 4: AWS S3 + CloudFront

**Best for**: High traffic, professional deployment

**Steps:**

1. **Create S3 Bucket**
   ```bash
   aws s3 mb s3://stptoken-website --region us-east-1
   ```

2. **Configure for Static Website**
   ```bash
   aws s3 website s3://stptoken-website \
     --index-document index.html \
     --error-document index.html
   ```

3. **Upload Files**
   ```bash
   aws s3 sync . s3://stptoken-website \
     --exclude ".git/*" \
     --exclude "*.md"
   ```

4. **Make Public**
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "PublicReadGetObject",
         "Effect": "Allow",
         "Principal": "*",
         "Action": "s3:GetObject",
         "Resource": "arn:aws:s3:::stptoken-website/*"
       }
     ]
   }
   ```

5. **Setup CloudFront** (Optional but recommended)
   - Create CloudFront distribution
   - Point to S3 bucket
   - Add custom SSL certificate
   - Configure caching rules

---

### Option 5: Traditional Web Hosting

**For cPanel/FTP hosting:**

1. **Connect via FTP**
   ```
   Host: ftp.yourhost.com
   Username: your_username
   Password: your_password
   ```

2. **Upload Files**
   ```
   - Navigate to public_html or www folder
   - Upload all files:
     - index.html
     - css/
     - js/
     - All other files
   ```

3. **Set Permissions** (if needed)
   ```
   Files: 644
   Directories: 755
   ```

4. **Access Your Site**
   ```
   https://yourdomain.com
   ```

---

## 🔧 Post-Deployment Configuration

### 1. Configure SSL Certificate

**Netlify/Vercel**: Automatic HTTPS
**GitHub Pages**: Automatic HTTPS
**AWS CloudFront**: Add ACM certificate
**cPanel**: Use Let's Encrypt (free)

### 2. Setup Email Forwarding

If using custom domain (e.g., contact@stptoken.io):

1. Go to domain registrar
2. Setup email forwarding
3. Forward to: savhukvladimir9@gmail.com

### 3. Configure Contact Form (Future)

For newsletter subscription to work:

**Option A: FormSpree**
```html
<form action="https://formspree.io/f/YOUR_ID" method="POST">
  <input type="email" name="email">
  <button type="submit">Subscribe</button>
</form>
```

**Option B: Netlify Forms**
```html
<form name="newsletter" netlify>
  <input type="email" name="email">
  <button type="submit">Subscribe</button>
</form>
```

**Option C: ConvertKit/Mailchimp**
- Create account
- Get embed code
- Replace form in HTML

---

## 📊 Analytics Setup

### Google Analytics

1. **Create GA4 Property**
   - Go to https://analytics.google.com
   - Create new property
   - Get Measurement ID

2. **Add to Website**
   ```html
   <!-- Add before </head> in index.html -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
   <script>
     window.dataLayer = window.dataLayer || [];
     function gtag(){dataLayer.push(arguments);}
     gtag('js', new Date());
     gtag('config', 'G-XXXXXXXXXX');
   </script>
   ```

### Alternative: Simple Analytics

For privacy-focused analytics:
- https://simpleanalytics.com
- Lightweight and GDPR compliant

---

## 🔍 SEO Optimization

### 1. Submit to Search Engines

**Google Search Console**
```
1. Go to https://search.google.com/search-console
2. Add property
3. Verify ownership
4. Submit sitemap (optional)
```

**Bing Webmaster Tools**
```
1. Go to https://www.bing.com/webmasters
2. Add site
3. Verify
4. Submit sitemap
```

### 2. Create Sitemap (Optional)

Create `sitemap.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://yourdomain.com/</loc>
    <lastmod>2024-12-01</lastmod>
    <priority>1.0</priority>
  </url>
</urlset>
```

### 3. Create robots.txt

Create `robots.txt`:
```
User-agent: *
Allow: /

Sitemap: https://yourdomain.com/sitemap.xml
```

---

## 🎯 Performance Optimization

### 1. Enable Compression (Gzip/Brotli)

**Netlify**: Automatic
**Vercel**: Automatic
**Apache (.htaccess)**:
```apache
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript
</IfModule>
```

### 2. Enable Browser Caching

**Netlify (_headers file)**:
```
/*
  Cache-Control: public, max-age=31536000
/*.html
  Cache-Control: public, max-age=0, must-revalidate
```

### 3. Image Optimization (Future)

When adding images:
- Use WebP format
- Compress images (TinyPNG, ImageOptim)
- Lazy load images
- Use responsive images

---

## 🔐 Security Headers

### Netlify (_headers file)

```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  X-XSS-Protection: 1; mode=block
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=()
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net; font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net; img-src 'self' data: https:;
```

---

## 📱 Mobile App Integration (Future)

### Progressive Web App (PWA)

1. **Create manifest.json**
```json
{
  "name": "Save The Planet Token",
  "short_name": "STP",
  "description": "Each Token Saves a Life on Earth",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0a1f1f",
  "theme_color": "#f4d03f",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

2. **Add to index.html**
```html
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#0a1f1f">
```

---

## 🧪 Testing Before Going Live

### 1. Cross-Browser Testing
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile browsers

### 2. Device Testing
- [ ] Desktop (1920x1080)
- [ ] Laptop (1366x768)
- [ ] Tablet (768x1024)
- [ ] Mobile (375x667)

### 3. Performance Testing
- Lighthouse audit (Chrome DevTools)
- GTmetrix: https://gtmetrix.com
- PageSpeed Insights: https://pagespeed.web.dev

### 4. Functionality Testing
- [ ] All links work
- [ ] Form validation works
- [ ] Copy buttons work
- [ ] Navigation smooth scrolls
- [ ] Mobile menu works
- [ ] Animations trigger correctly

---

## 🌍 Domain Setup

### 1. Purchase Domain

**Recommended Registrars:**
- Namecheap (affordable)
- Google Domains (easy)
- Cloudflare (best DNS)

### 2. Configure DNS

**For Netlify:**
```
Type: A
Name: @
Value: 75.2.60.5

Type: CNAME
Name: www
Value: your-site.netlify.app
```

**For Vercel:**
```
Type: A
Name: @
Value: 76.76.21.21

Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

### 3. Wait for Propagation

DNS changes take 1-24 hours to propagate worldwide.

Check status: https://www.whatsmydns.net

---

## 📧 Email Setup

### Option 1: Google Workspace
- Professional email (contact@yourdomain.com)
- $6/month per user
- Setup: https://workspace.google.com

### Option 2: Zoho Mail
- Free for 5 users
- Custom domain email
- Setup: https://www.zoho.com/mail

### Option 3: Email Forwarding
- Free
- Forward to Gmail
- Setup in domain registrar

---

## 🎉 Launch Checklist

### Pre-Launch
- [ ] Domain purchased and configured
- [ ] Website deployed
- [ ] SSL certificate active
- [ ] All links tested
- [ ] Mobile responsive checked
- [ ] Forms working
- [ ] Analytics installed
- [ ] SEO tags verified

### Launch Day
- [ ] Announce on Telegram
- [ ] Tweet from X account
- [ ] Update BSCScan profile
- [ ] Send email to community
- [ ] Monitor website performance
- [ ] Check for errors

### Post-Launch
- [ ] Submit to search engines
- [ ] Monitor analytics
- [ ] Collect feedback
- [ ] Plan updates
- [ ] Continue marketing

---

## 🆘 Troubleshooting

### Issue: Website not loading

**Solutions:**
1. Check DNS propagation
2. Verify deployment status
3. Check browser console for errors
4. Clear cache and hard reload

### Issue: HTTPS not working

**Solutions:**
1. Wait for SSL provisioning (can take 24 hours)
2. Check domain DNS configuration
3. Verify SSL certificate status
4. Contact hosting support

### Issue: Images not displaying

**Solutions:**
1. Check file paths (relative vs absolute)
2. Verify file permissions
3. Check image formats supported
4. Look for console errors

---

## 📞 Support Resources

### Netlify
- Docs: https://docs.netlify.com
- Support: https://answers.netlify.com

### Vercel
- Docs: https://vercel.com/docs
- Support: https://vercel.com/support

### GitHub Pages
- Docs: https://docs.github.com/pages
- Support: GitHub Community

---

## 🔄 Updating Your Website

### Method 1: Direct File Upload
1. Make changes locally
2. Re-upload via FTP or drag & drop
3. Clear CDN cache if applicable

### Method 2: Git Deployment
```bash
# Make changes
git add .
git commit -m "Update content"
git push

# Automatically deploys (if configured)
```

---

<div align="center">

## 🚀 Ready to Deploy!

Your professional crypto website is ready for the world.

**Need Help?** Contact: savhukvladimir9@gmail.com

</div>